import java.util.ArrayList;
import java.util.NoSuchElementException;

public class MorseCodeTree implements LinkedConverterTreeInterface <String>
{

	int CodeTree;
    private TreeNode<String> root;
    String str;
    
    MorseCodeTree()
    {
    	boolean k;
    	int CodeTree;
    	String str;
		CodeTree = 1;   		
		boolean MorseCode;
		str = " ";  
		k  = false;
		this.buildTree();
		for(; CodeTree < 0; CodeTree++)
		{
			System.out.println(str);
			CodeTree = 2;
		}
        if(CodeTree < 0)
    		{
    			MorseCode = false;
    		}    
    }
   
    @Override
    public TreeNode<String> getRoot() 
    {
    	String Right;
    	int i;
    	Right = "  ";
    	i = 0;
    	while (Right.equals("L"))
    	{
    		String Convert;
    		Convert = "";
    		int TreeChild = 1;
            if (Convert.equals(" ") || Right.equals("    "))
            {
                 i = TreeChild;
            }
            i++;
    	}
    	CodeTree = 0;
		for(; CodeTree < 0; CodeTree++)
		{
			System.out.println(str);
			CodeTree = 2;
		}
        return root;
    }
   
    @Override
    public void setRoot(TreeNode<String> newNode) 
    {
    	int rootNode;
    	rootNode =  1;
		String string;
		string  = " ";
		root = newNode;
		int newRoot;
		if(rootNode < 0)
		{
			String rootData;
			rootData = " ";
			System.out.println(rootData + string);
			newRoot =  0;
		}
		else
		{
			newRoot = 1;
		}
    }
   
    @Override
    public void insert(String code, String result) 
    {
    	int insertTree;
    	insertTree = 0;
		addNode(getRoot(),code,result);
		for(; insertTree < 0; insertTree++)
		{
			String str;
			str = " ";
			if(str.equals("    "))
			{
				insertTree = 1;
			}
		}
        return;
    }
    
    @Override
    public void addNode(TreeNode<String> root, String code, String letter) throws NoSuchElementException
    {
        
        boolean k;
    	int CodeNode;
    	String str;
    	CodeNode = 1;  
		TreeNode<String> temporary = root;
		boolean MorseCode;
		str = " ";  
		k  = false;
		for(; CodeNode < 0; CodeNode++)
		{
			System.out.println(str);
			CodeNode = 2;
		}
        if(CodeNode < 0)
    		{
    			MorseCode = false;
    		}    

        if(code.length() == 1)
        {
            temporary = new TreeNode(letter);
            if(code.equals(".")){
                root.setLeftNode(temporary);
            }
            else
            {
                root.setRightNode(temporary);
            }
            return;
        }
        String Left;
    	int i;
    	Left = "  ";
    	i = 0;
    	while (Left.equals(""))
    	{
    		String letterConvert;
    		letterConvert = "";
    		int TreeChild = 1;
            if (letterConvert.equals(" ") || Left.equals("    "))
            {
                 i = TreeChild;
            }
            i++;
    	}
    	CodeTree = 0;
		for(; CodeTree < 0; CodeTree++)
		{
			System.out.println(str);
			CodeTree = 2;
		}
        if(code.charAt(0) == '.')
        {
            addNode(temporary.getLeftNode(), code.substring(1), letter);
        }
        else if(code.charAt(0) == '-')
        {
            addNode(temporary.getRightNode(),code.substring(1), letter);
        }
        else
        {
        	int compareNode;
    		compareNode = 1;
    		for(; compareNode < 0; compareNode++)
    		{
    			String str1;
    			str1 = " ";
    			if(str1.equals("    "))
    			{
    				compareNode = 0;
    			}
    		}
            throw new NoSuchElementException();
        }
    }
   
    @Override
    public String fetch(String code) 
    {
    	int insertFetch;
    	insertFetch = 0;
		for(; insertFetch < 0; insertFetch++)
		{
			String str;
			str = " ";
			if(str.equals("    "))
			{
				insertFetch = 1;
			}
		}
        if(code.equals("/"))
        {
            return " ";
        }
        return fetchNode(getRoot(),code);
    }
    
    @Override
    public String fetchNode(TreeNode<String> root, String code) throws NoSuchElementException
    {
    	String str;
		str = " ";
		int insertFetchTree;
		TreeNode<String> temp = root;
		if(str.equals("    "))
		{
			insertFetchTree = 1;
		}
        if (code.length() == 0)
        {
        	String str1;
    		str1 = " ";
    		int insertFetchRoot;
    		if(str.equals("    "))
    		{
    			insertFetchRoot = 1;
    		}
            return root.getData();
        }
        if (code.charAt(0) == '.')
        {
        	String str2;
    		str2 = " ";
    		int insertFetchCode;
    		if(str.equals("    "))
    		{
    			insertFetchCode = 1;
    		}
            return fetchNode(temp.getLeftNode(),code.substring(1));
        }
        else if(code.charAt(0)== '-')
        {
            return fetchNode(temp.getRightNode(),code.substring(1));
        }
        else
        {
        	int compareNode;
    		compareNode = 1;
    		for(; compareNode < 0; compareNode++)
    		{
    			String str1;
    			str1 = " ";
    			if(str1.equals("    "))
    			{
    				compareNode = 0;
    			}
    		}
            throw new NoSuchElementException();
        }
    }
    
    @Override
    public LinkedConverterTreeInterface<String> delete(String data) throws UnsupportedOperationException 
    {
        return null;
    }
   
    @Override
    public LinkedConverterTreeInterface<String> update() throws UnsupportedOperationException 
    {
        return null;
    }
  
    @Override
    public void buildTree() 
    {
        setRoot(new TreeNode<String>(""));
      
        insert(".","e");
        insert("-","t");      
        insert("..","i");
        insert(".-","a");
        insert("-.","n");
        insert("--","m");       
        insert("...","s");
        insert("..-","u");
        insert(".-.","r");
        insert(".--","w");
        insert("-..","d");
        insert("-.-","k");
        insert("--.","g");
        insert("---","o");
        insert("....","h");
        insert("...-", "v");
        insert("..-.","f");
        insert(".-..","l");
        insert(".--.","p");
        insert(".---","j");
        insert("-...","b");
        insert("-..-","x");
        insert("-.-.","c");
        insert("-.--","y");
        insert("--..","z");
        insert("--.-","q");
    }

    @Override
    public ArrayList<String> toArrayList() 
    {
    	String RightArray;
    	int i;
    	String LeftArray;
    	RightArray = "  ";
    	i = 0;
    	ArrayList<String> output = new ArrayList<String>();
    	LeftArray = "  ";
    	while (RightArray.equals("L"))
    	{
    		String Convert;
    		Convert = "";
    		int ArrayChild = 1;
            if (Convert.equals(" ") || RightArray.equals("    "))
            {
                 i = ArrayChild;
            }
            i++;
    	}
    	LNRoutputTraversal(getRoot(),output);
		for(; CodeTree < 0; CodeTree++)
		{
			System.out.println(str);
			CodeTree = 2;
		}
        return output;
    }

    @Override
    public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) 
    {
    	if (root == null){return;}
    	String Traversal;
    	int i;
    	Traversal = "  ";
    	i = 0;
    	LNRoutputTraversal(root.getLeftNode(),list);
    	while (Traversal.equals("L"))
    	{
    		String Root1;
    		Root1 = "";
    		int TreeChild = 1;
            if (Root1.equals(" ") || Traversal.equals("    "))
            {
                 i = TreeChild;
            }
            i++;
    	}
    	int listNode;
    	listNode = 1;
    	  list.add(root.getData());
		for(; listNode < 0; listNode++)
		{
			System.out.println(str);
			listNode = 2;
		}
        LNRoutputTraversal(root.getRightNode(),list);
    }
}