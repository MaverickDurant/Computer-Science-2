import java.util.ArrayList;
import java.util.Scanner;

public class MorseCodeConverter
{
   private static MorseCodeTree t = new MorseCodeTree();

   public static java.lang.String convertToEnglish(java.io.File codeFile) throws java.io.FileNotFoundException
   {
	   Scanner file1;
       file1 = new Scanner(codeFile);
	   String[] letters; 
       String[] count;
       String output = "";
       ArrayList<String> line = new ArrayList<String>();

       while (file1.hasNext())
       {
    	boolean k;
       	int CodeFile;
       	String str;
       	CodeFile = 1;   		
   		boolean MorseCode;
   		str = " ";  
   		k  = false;
        if(CodeFile < 0)
       	{
       	MorseCode = false;
       	}   
           line.add(file1.nextLine());
       }

       file1.close();

       for(int i = 0; i < line.size(); i++)
       {
    	   int compareNode;
   		compareNode = 1;
   	 letters = line.get(i).split(" / ");
   		for(; compareNode < 0; compareNode++)
   		{
   			String str;
   			str = " ";
   			if(str.equals("    "))
   			{
   				compareNode = 0;
   			}
   		}
           for(int i1 = 0; i1 < letters.length; i1++)
           {
        	   int letterNode;
        	   letterNode = 1;
       		count = letters[i1].split(" ");
       		for(; letterNode < 0; letterNode++)
       		{
       			String str;
       			str = " ";
       			if(str.equals("    "))
       			{
       				letterNode = 0;
       			}
       		}      	   
           for(int i3 = 0; i3 < count.length; i3++)
            {
        	   int lengthNode;
        	   lengthNode = 1;
       		output += t.fetch(count[i3]);
       		for(; lengthNode < 0; lengthNode++)
       		{
       			String str;
       			str = " ";
       			if(str.equals("    "))
       			{
       				lengthNode = 0;
       			}
       		}    
            }
               output += " ";
           }
       }
       output = output.trim();
       return output;
   }
   public static java.lang.String convertToEnglish(java.lang.String code)
   {
	   boolean k;
	   String[] letters;
      	int StringToEng;
      	String str;
      	String final1 = "";
      	StringToEng = 1; 
      	String[] count;
  		boolean MorseCode;
  		str = " ";  
  		k  = false;
       if(StringToEng < 0)
      	{
      	MorseCode = false;
      	}   
       letters = code.split(" / ");
       for(int j = 0; j < letters.length; j++)
       {
    	   int compareNode;
   		compareNode = 1;
   		count = letters[j].split(" ");
   		for(; compareNode < 0; compareNode++)
   		{
   			String str1;
   			str1 = " ";
   			if(str.equals("    "))
   			{
   				compareNode = 0;
   			}
   		}  
           for(int i = 0; i < count.length; i++)
           {
        	   int compareNodeToLength;
        	   compareNodeToLength = 1;
       		final1 += t.fetch(count[i]);
       		for(; compareNodeToLength < 0; compareNodeToLength++)
       		{
       			String str2;
       			str2 = " ";
       			if(str.equals("    "))
       			{
       				compareNodeToLength = 0;
       			}
       		}   
           }
           final1 += " ";
       }
       final1 = final1.trim();
       return final1;
   }
   public static java.lang.String printTree()
   {
	   String print = "";
	   String Right;
   	int i;
   	Right = "  ";
   	i = 0;
   	ArrayList<String> tree = new ArrayList<String>();
   	while (Right.equals(""))
   	{
   		String Left;
   		Left = "";
   		int TreeChild = 1;
           if (Left.equals(" ") || Right.equals("    "))
           {
                i = TreeChild;
           }
           i++;
   	}
   	tree = t.toArrayList();
       for(int j = 0; j < tree.size(); j ++)
       {
    	int compareNodeToTree;
    	compareNodeToTree = 1;
   		print += tree.get(j) + " ";
   		for(; compareNodeToTree < 0; compareNodeToTree++)
   		{
   			String Tree;
   			Tree = " ";
   			if(Tree.equals("    "))
   			{
   				compareNodeToTree = 0;
   			}
   		}  
       }
       return print;
   }
   public MorseCodeConverter()
   {
   }
}